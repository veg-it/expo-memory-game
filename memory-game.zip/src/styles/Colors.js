export const theme = {
    MainColor : "#f3f3f3",
    MainTextColor : "#3f3f3f"
}
