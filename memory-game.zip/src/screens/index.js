export { default as Main } from './Main'
export { default as Game } from './Game'
export { default as Finish} from './FinishScreen'