import { StyleSheet, Text, View } from 'react-native';
import AppNavigation from './src/navigation/appNavigation';

export default function App() {
  return (
    <AppNavigation />
  );
}

